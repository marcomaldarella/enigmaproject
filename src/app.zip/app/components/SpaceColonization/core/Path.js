import { Defaults } from './Defaults'
import * as Vec2 from 'vec2'

let inside = require('point-in-polygon')

export default class Path {
  constructor(polygon, type, ctx, settings) {
    this.polygon = polygon // array of arrays containing coordinates defining a polygon ([[x0,y0],[x1,y1],...])
    this.ctx = ctx // global canvas context
    this.type = type // string either 'Bounds' or 'Obstacle'

    this.transformedPolygon = polygon // Paths are initialized without any transformations by default
    this.origin = { x: 0, y: 0 } // origin point used for translation
    this.scale = 1 // multiplication factor for polygon coordinates
    this.width = -1 // width of transformed polygon - will be calculated using this.calculateDimensions()
    this.height = -1 // height of transformed polygon - will be calculated using this.calculateDimensions()
    this.isCentered = false // whether or not to automatically translate to screen center

    this.settings = Object.assign({}, Defaults, settings)

    this.calculateDimensions()
  }

  // Check if provided coordinates are inside polygon defined by this Path
  contains(x, y) {
    return inside([x, y], this.polygon)
  }

  // Relative translation
  moveBy(x, y) {
    this.origin.x += x
    this.origin.y += y

    this.createTransformedPolygon()
  }

  // Absolute translation
  moveTo(x, y) {
    if (this.isCentered) {
      this.origin.x = x - this.width / 2
      this.origin.y = y - this.height / 2
    } else {
      this.origin.x = x
      this.origin.y = y
    }

    this.createTransformedPolygon()
  }

  setScale(factor) {
    this.scale *= factor
    this.createTransformedPolygon()
    this.calculateDimensions()

    if (this.isCentered) {
      this.moveTo(window.innerWidth / 2, window.innerHeight / 2)
    }
  }

  // Calculate total path length by adding up all line segment lengths (distances between polygon points)
  getTotalLength() {
    let totalLength = 0

    for (let i = 1; i < this.polygon.length; i++) {
      totalLength += Vec2(
        this.polygon[i][0] * this.scale,
        this.polygon[i][1] * this.scale
      ).distance(
        Vec2(
          this.polygon[i - 1][0] * this.scale,
          this.polygon[i - 1][1] * this.scale
        )
      )
    }

    return totalLength
  }

  // Calculates the real width and height of the transformed polygon
  calculateDimensions() {
    let leftMostCoordinate = this.transformedPolygon[0][0],
      rightMostCoordinate = this.transformedPolygon[0][0],
      topMostCoordinate = this.transformedPolygon[0][1],
      bottomMostCoordinate = this.transformedPolygon[0][1]

    for (let i = 0; i < this.transformedPolygon.length; i++) {
      if (this.transformedPolygon[i][0] < leftMostCoordinate) {
        leftMostCoordinate = this.transformedPolygon[i][0]
      } else if (this.transformedPolygon[i][0] > rightMostCoordinate) {
        rightMostCoordinate = this.transformedPolygon[i][0]
      }

      if (this.transformedPolygon[i][1] < topMostCoordinate) {
        topMostCoordinate = this.transformedPolygon[i][1]
      } else if (this.transformedPolygon[i][1] > bottomMostCoordinate) {
        bottomMostCoordinate = this.transformedPolygon[i][1]
      }
    }

    this.width = Math.abs(rightMostCoordinate - leftMostCoordinate)
    this.height = Math.abs(bottomMostCoordinate - topMostCoordinate)
  }

  // Create coordinates for the "transformed" version of this path, taking into consideration translation and scaling
  createTransformedPolygon() {
    this.transformedPolygon = []

    for (let i = 0; i < this.polygon.length; i++) {
      this.transformedPolygon.push([
        this.polygon[i][0] * this.scale + this.origin.x,
        this.polygon[i][1] * this.scale + this.origin.y,
      ])
    }
  }

  draw() {
    if (
      (this.settings.ShowBounds && this.type == 'Bounds') ||
      (this.settings.ShowObstacles && this.type == 'Obstacles')
    ) {
      this.ctx.beginPath()
      this.ctx.moveTo(
        this.transformedPolygon[0][0],
        this.transformedPolygon[0][1]
      )

      // Draw sequential lines to all points of the polygon
      for (let i = 0; i < this.transformedPolygon.length; i++) {
        this.ctx.lineTo(
          this.transformedPolygon[i][0],
          this.transformedPolygon[i][1]
        )
      }

      // Draw line back to first point to close the polygon
      // this.ctx.lineTo(this.transformedPolygon[0][0], this.transformedPolygon[0][1]);

      switch (this.type) {
        case 'Bounds':
          this.ctx.strokeStyle = this.settings.Colors.BoundsBorderColor
          this.ctx.lineWidth = this.settings.BoundsBorderThickness
          this.ctx.fillStyle = this.settings.Colors.BoundsFillColor

          this.ctx.stroke()
          this.ctx.lineWidth = 1

          break

        case 'Obstacle':
          this.ctx.fillStyle = this.settings.Colors.ObstacleFillColor
          break
      }

      this.ctx.fill()

      // Draw bounding box
      // this.ctx.beginPath();
      // this.ctx.moveTo(this.origin.x, this.origin.y);
      // this.ctx.lineTo(this.origin.x + this.width, this.origin.y);
      // this.ctx.lineTo(this.origin.x + this.width, this.origin.y + this.height);
      // this.ctx.lineTo(this.origin.x, this.origin.y + this.height);
      // this.ctx.lineTo(this.origin.x, this.origin.y);
      // this.ctx.strokeStyle = 'rgba(255,255,255,1)';
      // this.ctx.stroke();
    }
  }
}
