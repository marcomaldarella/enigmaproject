export const decksItems = [
  {
    name: "Enigma Project Overview",
    url: "https://enigmaslides.netlify.app",
  }
];
